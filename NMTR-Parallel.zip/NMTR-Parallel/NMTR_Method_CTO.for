      module umat_kinds
        implicit none
        integer, parameter :: dp = selected_real_kind(15, 307)
      end module umat_kinds


      module umat_utils
        use umat_kinds
        implicit none
      contains

        subroutine set_zero_vec6(a)
          real(dp), intent(out) :: a(6)
          integer :: i
          do i = 1, 6
            a(i) = 0.0_dp
          end do
        end subroutine

        subroutine set_zero_vec4(a)
          real(dp), intent(out) :: a(4)
          integer :: i
          do i = 1, 4
            a(i) = 0.0_dp
          end do
        end subroutine

        subroutine set_zero_vec3(a)
          real(dp), intent(out) :: a(3)
          integer :: i
          do i = 1, 3
            a(i) = 0.0_dp
          end do
        end subroutine

        subroutine set_zero_mat66(a)
          real(dp), intent(out) :: a(6,6)
          integer :: i,j
          do i = 1, 6
            do j = 1, 6
              a(i,j) = 0.0_dp
            end do
          end do
        end subroutine

        subroutine set_zero_mat44(a)
          real(dp), intent(out) :: a(4,4)
          integer :: i,j
          do i = 1, 4
            do j = 1, 4
              a(i,j) = 0.0_dp
            end do
          end do
        end subroutine

        subroutine eye66(a)
          real(dp), intent(out) :: a(6,6)
          integer :: i
          call set_zero_mat66(a)
          do i = 1, 6
            a(i,i) = 1.0_dp
          end do
        end subroutine

        function dot4(a,b) result(v)
          real(dp), intent(in) :: a(4), b(4)
          real(dp) :: v
          integer :: i
          v = 0.0_dp
          do i = 1, 4
            v = v + a(i)*b(i)
          end do
        end function

        function norm2_4(a) result(v)
          real(dp), intent(in) :: a(4)
          real(dp) :: v
          v = sqrt(dot4(a,a))
        end function

        function norm2_6_eng(a) result(v)
          real(dp), intent(in) :: a(6)
          real(dp) :: v
          v = sqrt(a(1)*a(1)+a(2)*a(2)+a(3)*a(3) 
     &         + 2.0_dp*(a(4)*a(4)+a(5)*a(5)+a(6)*a(6)))
        end function

        function norm2_mat66(a) result(v)
          real(dp), intent(in) :: a(6,6)
          real(dp) :: v
          integer :: i,j
          v = 0.0_dp
          do i=1,6
            do j=1,6
              v = v + a(i,j)*a(i,j)
            end do
          end do
          v = sqrt(v)
        end function

        subroutine matvec44(a,x,y)
          real(dp), intent(in) :: a(4,4), x(4)
          real(dp), intent(out) :: y(4)
          integer :: i,j
          do i = 1, 4
            y(i) = 0.0_dp
            do j = 1, 4
              y(i) = y(i) + a(i,j)*x(j)
            end do
          end do
        end subroutine

        subroutine matvec66(a,x,y)
          real(dp), intent(in) :: a(6,6), x(6)
          real(dp), intent(out) :: y(6)
          integer :: i,j
          do i = 1, 6
            y(i) = 0.0_dp
            do j = 1, 6
              y(i) = y(i) + a(i,j)*x(j)
            end do
          end do
        end subroutine

        subroutine matmul44(a,b,c)
          real(dp), intent(in) :: a(4,4), b(4,4)
          real(dp), intent(out) :: c(4,4)
          integer :: i,j,k
          do i = 1, 4
            do j = 1, 4
              c(i,j) = 0.0_dp
              do k = 1, 4
                c(i,j) = c(i,j) + a(i,k)*b(k,j)
              end do
            end do
          end do
        end subroutine

        subroutine trans44(a,at)
          real(dp), intent(in) :: a(4,4)
          real(dp), intent(out) :: at(4,4)
          integer :: i,j
          do i = 1, 4
            do j = 1, 4
              at(i,j) = a(j,i)
            end do
          end do
        end subroutine

        subroutine copy4(a,b)
          real(dp), intent(in) :: a(4)
          real(dp), intent(out) :: b(4)
          integer :: i
          do i=1,4
            b(i)=a(i)
          end do
        end subroutine

        subroutine copy6(a,b)
          real(dp), intent(in) :: a(6)
          real(dp), intent(out) :: b(6)
          integer :: i
          do i=1,6
            b(i)=a(i)
          end do
        end subroutine

        subroutine copy44(a,b)
          real(dp), intent(in) :: a(4,4)
          real(dp), intent(out) :: b(4,4)
          integer :: i,j
          do i=1,4
            do j=1,4
              b(i,j)=a(i,j)
            end do
          end do
        end subroutine

        subroutine inverse44_pivot(a, ainv, det, info)
          real(dp), intent(in) :: a(4,4)
          real(dp), intent(out) :: ainv(4,4)
          real(dp), intent(out) :: det
          integer, intent(out) :: info

          real(dp) :: aug(4,8), tmp, maxv
          integer :: i,j,k,piv

          info = 0
          det = 1.0_dp

          do i=1,4
            do j=1,4
              aug(i,j)=a(i,j)
              aug(i,j+4)=0.0_dp
            end do
            aug(i,i+4)=1.0_dp
          end do

          do i=1,4
            piv = i
            maxv = abs(aug(i,i))
            do k=i+1,4
              if (abs(aug(k,i)) > maxv) then
                maxv = abs(aug(k,i))
                piv = k
              end if
            end do

            if (maxv == 0.0_dp) then
              info = 1
              det = 0.0_dp
              return
            end if

            if (piv /= i) then
              det = -det
              do j=1,8
                tmp = aug(i,j)
                aug(i,j) = aug(piv,j)
                aug(piv,j) = tmp
              end do
            end if

            det = det * aug(i,i)
            tmp = aug(i,i)
            do j=1,8
              aug(i,j)=aug(i,j)/tmp
            end do

            do k=1,4
              if (k /= i) then
                tmp = aug(k,i)
                do j=1,8
                  aug(k,j)=aug(k,j)-tmp*aug(i,j)
                end do
              end if
            end do
          end do

          do i=1,4
            do j=1,4
              ainv(i,j)=aug(i,j+4)
            end do
          end do
        end subroutine

        function safe_exp(x) result(v)
          real(dp), intent(in) :: x
          real(dp) :: v
          v = exp(x)
        end function

        function secant_bulk(pold, ck, epsv) result(bkw)
          real(dp), intent(in) :: pold, ck, epsv
          real(dp) :: bkw
          real(dp) :: z

          if (epsv == 0.0_dp) then
            bkw = pold*ck
          else
            z = ck*epsv
            if (abs(z) < 1.0e-14_dp) then
              bkw = pold*ck*(1.0_dp + 0.5_dp*z + z*z/6.0_dp)
            else
              bkw = pold*(exp(z)-1.0_dp)/epsv
            end if
          end if
        end function

      end module umat_utils


      module umat_model
        use umat_kinds
        use umat_utils
        implicit none
      contains

        subroutine TenMat1(II,IP,Ivol,Isym)
          real(dp), intent(out) :: II(6,6),IP(6,6),Ivol(6,6),Isym(6,6)
          integer :: i,j

          call set_zero_mat66(II)
          call set_zero_mat66(IP)
          call set_zero_mat66(Ivol)
          call set_zero_mat66(Isym)

          do i=1,3
            do j=1,3
              Ivol(i,j)=1.0_dp/3.0_dp
              IP(i,j)=-1.0_dp/3.0_dp
            end do
          end do

          do i=1,3
            Isym(i,i)=1.0_dp
            Isym(i+3,i+3)=0.5_dp
            II(i,i)=1.0_dp
            II(i+3,i+3)=1.0_dp
            IP(i,i)=2.0_dp/3.0_dp
            IP(i+3,i+3)=0.5_dp
          end do
        end subroutine

        subroutine TenMat2(dgamma,nw,delta,Inw,gamI,gamnw,nwI,nwnw)
          real(dp), intent(in) :: dgamma(6),nw(6),delta(6)
          real(dp), intent(out):: Inw(6,6),gamI(6,6),gamnw(6,6),
     #  nwI(6,6),nwnw(6,6)
          integer :: i,j
          do i=1,6
            do j=1,6
              Inw(i,j)=delta(i)*nw(j)
              gamI(i,j)=dgamma(i)*delta(j)
              gamnw(i,j)=dgamma(i)*nw(j)
              nwI(i,j)=nw(i)*delta(j)
              nwnw(i,j)=nw(i)*nw(j)
            end do
          end do
        end subroutine

        subroutine pqs(s,p,q)
          real(dp), intent(in) :: s(6)
          real(dp), intent(out) :: p,q
          p = (s(1)+s(2)+s(3))/3.0_dp
          q = sqrt(((s(1)-s(2))**2 + (s(2)-s(3))**2 + (s(3)-s(1))**2
     &         + 6.0_dp*(s(4)**2+s(5)**2+s(6)**2))/2.0_dp)
        end subroutine

        subroutine eval_state(paras,sdold,dev,dgamma,pold,pcold,cd,x,
     &                        g,nw,xs,xcd,nsdt)
          real(dp), intent(in) :: paras(4), sdold(6), dev, dgamma(6),
     #  pold, pcold, cd, x(4)
          real(dp), intent(out):: g(4), nw(6), xs(4), xcd(2), nsdt

          real(dp) :: p,q,pc,dphi,Mf,cp,ck,r
          real(dp) :: BKw,GKw,deve,eta,f,norm_sd
          real(dp) :: delta(6), sd(6), sdt(6)
          integer :: i

          p = x(1)
          q = x(2)
          pc = x(3)
          dphi = x(4)

          Mf = paras(1)
          cp = paras(2)
          ck = paras(3)
          r  = paras(4)

          call set_zero_vec6(delta)
          do i=1,3
            delta(i)=1.0_dp
          end do

          deve = dev - dphi*(2.0_dp*p - pc)
          BKw = secant_bulk(pold, ck, deve)
          GKw = r*BKw
          eta = 1.0_dp/(1.0_dp + 6.0_dp*GKw*dphi/(Mf*Mf))

          do i=1,6
            sd(i)=eta*(sdold(i)+2.0_dp*GKw*dgamma(i))
          end do

          norm_sd = norm2_6_eng(sd)
          if (norm_sd == 0.0_dp) then
            do i=1,6
              nw(i)=0.0_dp
            end do
            do i=1,3
              nw(i)=1.0_dp/sqrt(3.0_dp)
            end do
          else
            do i=1,6
              nw(i)=sd(i)/norm_sd
            end do
          end if

          xs(1)=BKw
          xs(2)=GKw
          xs(3)=deve
          xs(4)=eta

          f = q*q/(Mf*Mf) + p*(p-pc)

          xcd(1) = f/sqrt(cd*cd*dphi*dphi + f*f + 1.0e-12_dp) + 1.0_dp
          xcd(2) = cd*cd*dphi/sqrt(cd*cd*dphi*dphi+f*f+1.0e-12_dp)-cd

          do i=1,6
            sdt(i)=sdold(i)+2.0_dp*GKw*dgamma(i)
          end do
          nsdt = norm2_6_eng(sdt)

          g(1) = (p  - pold*exp(ck*deve))*cd
          g(2) = (q  - sqrt(3.0_dp/2.0_dp)*eta*nsdt)*cd
          g(3) = (pc - pcold*exp(cp*dphi*(2.0_dp*p-pc)))*cd
          g(4) = sqrt(cd*cd*dphi*dphi + f*f + 1.0e-12_dp) - cd*dphi + f
        end subroutine

        subroutine Jacob(paras,dgamma,pold,pcold,cd,x,nw,xs,xcd,nsdt,Jg)
          real(dp), intent(in) :: paras(4), dgamma(6), pold, pcold, cd, 
     #  x(4), nw(6), xs(4), xcd(2), nsdt
          real(dp), intent(out):: Jg(4,4)

          real(dp) :: p,q,pc,dphi,Mf,cp,ck,r
          real(dp) :: BKw,GKw,deve,eta
          real(dp) :: BK,rBK,nwgam,pc1
          real(dp) :: GKws(4)
          integer :: i,j

          p = x(1)
          q = x(2)
          pc = x(3)
          dphi = x(4)

          Mf = paras(1)
          cp = paras(2)
          ck = paras(3)
          r  = paras(4)

          BKw = xs(1)
          GKw = xs(2)
          deve= xs(3)
          eta = xs(4)

          BK = ck*pold*exp(ck*deve)

          if (deve == 0.0_dp) then
            rBK = r*pold*ck*ck
          else
            rBK = (r*BK-GKw)/deve
          end if

          nwgam = 0.0_dp
          do i=1,3
            nwgam = nwgam + nw(i)*dgamma(i)
          end do
          do i=4,6
            nwgam = nwgam + 2.0_dp*nw(i)*dgamma(i)
          end do

          GKws(1) = -2.0_dp*rBK*dphi
          GKws(2) =  0.0_dp
          GKws(3) =  rBK*dphi
          GKws(4) = -rBK*(2.0_dp*p-pc)

          do i=1,4
            do j=1,4
              Jg(i,j)=0.0_dp
            end do
          end do

          Jg(1,1) = 1.0_dp + 2.0_dp*dphi*BK
          Jg(1,2) = 0.0_dp
          Jg(1,3) = -dphi*BK
          Jg(1,4) = (2.0_dp*p-pc)*BK

          Jg(2,1) = -sqrt(3.0_dp/2.0_dp)*eta*GKws(1) * 
     & (2.0_dp*nwgam - 6.0_dp*eta*dphi*nsdt/(Mf*Mf))
          Jg(2,2) = 1.0_dp
          Jg(2,3) = -sqrt(3.0_dp/2.0_dp)*eta*GKws(3) * 
     & (2.0_dp*nwgam - 6.0_dp*eta*dphi*nsdt/(Mf*Mf))
          Jg(2,4) = -sqrt(3.0_dp/2.0_dp)*eta * 
     & (2.0_dp*nwgam*GKws(4)-6.0_dp*eta*nsdt*(GKw+dphi*GKws(4))/(Mf*Mf))

          pc1 = pcold*exp(cp*dphi*(2.0_dp*p-pc))
          Jg(3,1) = -2.0_dp*cp*dphi*pc1
          Jg(3,2) = 0.0_dp
          Jg(3,3) = 1.0_dp + cp*dphi*pc1
          Jg(3,4) = -cp*(2.0_dp*p-pc)*pc1

          Jg(4,1) = xcd(1)*(2.0_dp*p-pc)
          Jg(4,2) = xcd(1)*2.0_dp*q/(Mf*Mf)
          Jg(4,3) = -xcd(1)*p
          Jg(4,4) = xcd(2)

          do i=1,3
            do j=1,4
              Jg(i,j)=Jg(i,j)*cd
            end do
          end do
        end subroutine

        subroutine ConsStiff(nw,IP,Ivol,DDSDDE,paras,dgamma,pold,
     #  xs,xcd,x,info)
          real(dp), intent(in) :: nw(6),IP(6,6),Ivol(6,6),paras(4)
     #  ,dgamma(6),pold,xs(4),xcd(2),x(4)
          real(dp), intent(out):: DDSDDE(6,6)
          integer, intent(out) :: info

          real(dp) :: nwgam,a0,a1,a2,a3,a4,b0,b1,b2,c0,c1,c2,c3,c4,c5,c6
          real(dp) :: rBK,p,q,pc,dphi,Mf,cp,ck,r,BK,BKw,GKw,deve,eta
          real(dp) :: Inw(6,6),gamnw(6,6),nwI(6,6),nwnw(6,6),gamI(6,6)
          real(dp) :: delta(6)
          integer :: i,j

          info = 0
          p = x(1)
          q = x(2)
          pc = x(3)
          dphi = x(4)
          Mf = paras(1)
          cp = paras(2)
          ck = paras(3)
          r  = paras(4)
          BKw= xs(1)
          GKw= xs(2)
          deve=xs(3)
          eta= xs(4)

          call set_zero_vec6(delta)
          do i=1,3
            delta(i)=1.0_dp
          end do

          nwgam = 0.0_dp
          do i=1,3
            nwgam = nwgam + nw(i)*dgamma(i)
          end do
          do i=4,6
            nwgam = nwgam + 2.0_dp*nw(i)*dgamma(i)
          end do

          BK = ck*pold*exp(ck*deve)
          if (deve == 0.0_dp) then
            rBK = r*pold*ck*ck
          else
            rBK = (r*BK-GKw)/deve
          end if

          a0 = 1.0_dp + pc*cp*dphi + 2.0_dp*BK*dphi
          a1 = (1.0_dp + pc*cp*dphi)/a0
          a2 = -(2.0_dp*p-pc)/a0
          a3 = 2.0_dp*pc*cp*dphi/a0
          a4 = pc*cp*(2.0_dp*p-pc)/(a0*BK)

          b0 = xcd(1)*(((nwgam/sqrt(6.0_dp)-q*dphi/(Mf*Mf))*a2*
     #   rBK-q*GKw/(Mf*Mf)) 
     & *12.0_dp*q*eta/(Mf*Mf) + ((2.0_dp*a2-a4)*p-a2*pc)*BK) + xcd(2)

          if (b0 == 0.0_dp) then
            info = 1
            return
          end if

          b1 = -xcd(1)*((nwgam/sqrt(6.0_dp)-q*dphi/(Mf*Mf))*12.0_dp*q*a1
     #  *eta/(Mf*Mf)*rBK 
     & +(2.0_dp*a1-a3)*p*BK-a1*pc*BK)/b0

          b2 = -xcd(1)*2.0_dp*sqrt(6.0_dp)*q*GKw*eta/(Mf*Mf*b0)

          c0 = 2.0_dp*GKw*eta
          c1 = (a1+a2*b1)*BK
          c2 = a2*b2*BK
          c3 = 2.0_dp*eta*(a1+a2*b1)*rBK
          c4 = 2.0_dp*a2*eta*b2*rBK
          c5 = -2.0_dp*sqrt(6.0_dp)*q*eta/(Mf*Mf)*
     #       (b1*GKw+(a1+a2*b1)*rBK*dphi)
          c6 = -2.0_dp*sqrt(6.0_dp)*q*eta/(Mf*Mf)*
     #  (b2*GKw+a2*b2*rBK*dphi)

          call TenMat2(dgamma,nw,delta,Inw,gamI,gamnw,nwI,nwnw)

          do i=1,6
            do j=1,6
              DDSDDE(i,j)=c0*IP(i,j)+3.0_dp*c1*Ivol(i,j)+c2*Inw(i,j)+c3 
     &          *gamI(i,j)+c4*gamnw(i,j)+c5*nwI(i,j)+c6*nwnw(i,j)
            end do
          end do
        end subroutine

        subroutine TrustSolve(paras,sdold,dev,dgamma,xold,cd,x,
     # iteration,info)
      real(dp), intent(in) :: paras(4),sdold(6),dev,dgamma(6),xold(4),cd
          real(dp), intent(inout) :: x(4)
          integer, intent(out) :: iteration, info

          integer, parameter :: Maxit = 100
          integer, parameter :: Mmax  = 10

          real(dp) :: pold,qold,pcold,Mf,cp,ck
          real(dp) :: g(4),gnew(4),nw(6),nwnew(6),xs(4),xsnew(4),
     #   xcd(2),xcdnew(2)
          real(dp) :: Jg(4,4),B(4,4),Bt(4,4),Bd(4,4),ID2(4,4),
     #  D2(4,4),IJg(4,4)
      real(dp) :: v(4),vd(4),dxc(4),dxn(4),dxd(4),dx(4),xnew(4),dxnc(4)
          real(dp) :: norm_g,nsdt,nsdt_new,mold,mnew,Ared,
     #   Pred,ratio1,ratio2,ratio
          real(dp) :: tau1,tau2,tau3,tau4,delmax,del
          real(dp) :: norm_vd,vBdv,vIBdv,norm_dxc,norm_dxn,norm_nc,
     #    ncc,lam1,lam2,disc
          real(dp) :: ded, detJg, temp4(4)
          real(dp) :: mfun(Maxit),PredKm(Maxit),Hm(Mmax),SumPred
          integer :: i,j,k,mm,km,idxmax,inv_info

          info = 0
          iteration = 0

          pold = xold(1)
          qold = xold(2)
          pcold= xold(3)
          Mf   = paras(1)
          cp   = paras(2)
          ck   = paras(3)

          call eval_state(paras,sdold,dev,dgamma,pold,pcold,
     #  cd,x,g,nw,xs,xcd,nsdt)
          call Jacob(paras,dgamma,pold,pcold,cd,x,nw,xs,xcd,nsdt,Jg)

          norm_g = norm2_4(g)

          call set_zero_mat44(B)
          call set_zero_mat44(Bd)
          call set_zero_mat44(ID2)
          call set_zero_mat44(D2)

          do i=1,4
            do j=1,4
              B(i,j)=0.0_dp
              do k=1,4
                B(i,j)=B(i,j)+Jg(k,i)*Jg(k,j)
              end do
            end do
          end do

          do i=1,4
            D2(i,i)=sqrt(abs(B(i,i)))
            ID2(i,i)=1.0_dp/D2(i,i)
          end do

          ded = sqrt(2.0_dp/3.0_dp)*norm2_6_eng(dgamma)

          delmax = sqrt( (D2(1,1)*(pold-pold*exp(ck*dev)))**2 
     & + (D2(2,2)*(qold-sqrt(3.0_dp/2.0_dp)*nsdt))**2
     & + (D2(3,3)*(pcold-pcold*exp(cp*dev)))**2
     & + (D2(4,4)*sqrt((dev*dev+ded*ded)/((2.0_dp*qold/(Mf*Mf))**2 
     #  +(2.0_dp*pold-pcold)**2)))**2 )
          if (delmax < 1.0_dp) delmax = 1.0_dp
          del = delmax

          do i=1,Maxit
            mfun(i)=0.0_dp
            PredKm(i)=0.0_dp
          end do
          mfun(1)=0.5_dp*dot4(g,g)

          km = 1
          mm = 1

          do while (norm_g > 1.0e-6_dp .and. iteration < Maxit)

            iteration = iteration + 1

            do i=1,4
              do j=1,4
                B(i,j)=0.0_dp
                do k=1,4
                  B(i,j)=B(i,j)+Jg(k,i)*Jg(k,j)
                end do
              end do
            end do

            do i=1,4
              D2(i,i)=sqrt(abs(B(i,i)))
              ID2(i,i)=1.0_dp/D2(i,i)
            end do

            do i=1,4
              do j=1,4
                Bd(i,j)=ID2(i,i)*B(i,j)*ID2(j,j)
              end do
            end do

            do i=1,4
              v(i)=0.0_dp
              do j=1,4
                v(i)=v(i)+Jg(j,i)*g(j)
              end do
            end do

            do i=1,4
              vd(i)=ID2(i,i)*v(i)
            end do

            norm_vd = norm2_4(vd)

            vBdv = 0.0_dp
            do i=1,4
              temp4(i)=0.0_dp
              do j=1,4
                temp4(i)=temp4(i)+Bd(i,j)*vd(j)
              end do
            end do
            do i=1,4
              vBdv=vBdv+vd(i)*temp4(i)
            end do

            if (vBdv <= 0.0_dp) then
              tau1 = 1.0_dp
            else
              tau1 = min(1.0_dp, norm_vd**3/(del*vBdv))
            end if

            do i=1,4
              dxc(i) = -tau1*del*vd(i)/norm_vd
            end do
            norm_dxc = norm2_4(dxc)

            if (norm_dxc >= del) then
              do i=1,4
                dxd(i) = -del*vd(i)/norm_vd
              end do
            else
              call inverse44_pivot(Jg,IJg,detJg,inv_info)
              if (inv_info /= 0) then
                info = 1
                return
              end if

              do i=1,4
                dxn(i)=0.0_dp
                do j=1,4
                  dxn(i)=dxn(i)-IJg(i,j)*g(j)
                end do
                dxn(i)=D2(i,i)*dxn(i)
              end do
              norm_dxn = norm2_4(dxn)

              if (norm_dxn <= del) then
                do i=1,4
                  dxd(i)=dxn(i)
                end do
              else
                vIBdv = 0.0_dp
                do i=1,4
                  vIBdv = vIBdv + vd(i)*(-dxn(i))
                end do

                tau4 = norm_vd**4/(vBdv*vIBdv)
                tau3 = 0.8_dp*tau4 + 0.2_dp
                do i=1,4
                  dxn(i)=tau3*dxn(i)
                  dxnc(i)=dxn(i)-dxc(i)
                end do

                norm_nc = norm2_4(dxnc)
                ncc = dot4(dxnc,dxc)

              disc = 4.0_dp*ncc*ncc - 4.0_dp*norm_nc*norm_nc*
     $          (norm_dxc*norm_dxc-del*del)
                lam1 = (sqrt(disc)-2.0_dp*ncc)/(2.0_dp*norm_nc*norm_nc)
                lam2 = (-sqrt(disc)-2.0_dp*ncc)/(2.0_dp*norm_nc*norm_nc)

                if (lam1 > 0.0_dp) then
                  tau2 = lam1
                else if (lam2 > 0.0_dp) then
                  tau2 = lam2
                else
                  tau2 = 0.0_dp
                end if

                do i=1,4
                  dxd(i)=dxc(i)+tau2*(dxn(i)-dxc(i))
                end do
              end if
            end if

            do i=1,4
              dx(i)=ID2(i,i)*dxd(i)
              xnew(i)=x(i)+dx(i)
            end do

            mold = 0.5_dp*dot4(g,g)

            call eval_state(paras,sdold,dev,dgamma,pold,pcold,cd,
     #    xnew,gnew,nwnew,xsnew,xcdnew,nsdt_new)
            mnew = 0.5_dp*dot4(gnew,gnew)

            Ared = mold - mnew

            Pred = 0.0_dp
            do i=1,4
              Pred = Pred - vd(i)*dxd(i)
            end do
            do i=1,4
              do j=1,4
                Pred = Pred - 0.5_dp*dxd(i)*Bd(i,j)*dxd(j)
              end do
            end do

            ratio1 = Ared/Pred

            do i=1,Mmax
              Hm(i)=0.0_dp
            end do
            do i=1,mm
              Hm(i)=mfun(km-i+1)
            end do

            idxmax = 1
            do i=2,mm
              if (Hm(i) > Hm(idxmax)) idxmax = i
            end do

            SumPred = 0.0_dp
            do i=1,idxmax
              SumPred = SumPred + PredKm(km-i+1)
            end do

            if (km > 1) then
              ratio2 = (Hm(idxmax)-mnew)/SumPred
            else
              ratio2 = 0.0_dp
            end if

            if (ratio1 > ratio2) then
              ratio = ratio1
            else
              ratio = ratio2
            end if

            if (ratio > 0.75_dp) then
              do i=1,4
                x(i)=xnew(i)
                g(i)=gnew(i)
              end do
              do i=1,6
                nw(i)=nwnew(i)
              end do
              do i=1,4
                xs(i)=xsnew(i)
              end do
              do i=1,2
                xcd(i)=xcdnew(i)
              end do
              nsdt = nsdt_new
              del = min(2.0_dp*del,delmax)

              km = km + 1
              mfun(km)=mnew
              PredKm(km)=Pred
              mm = min(mm+1,Mmax)

              call Jacob(paras,dgamma,pold,pcold,cd,x,nw,xs,xcd,nsdt,Jg)
              norm_g = norm2_4(g)

            else if (ratio >= 0.1_dp) then
              do i=1,4
                x(i)=xnew(i)
                g(i)=gnew(i)
              end do
              do i=1,6
                nw(i)=nwnew(i)
              end do
              do i=1,4
                xs(i)=xsnew(i)
              end do
              do i=1,2
                xcd(i)=xcdnew(i)
              end do
              nsdt = nsdt_new

              km = km + 1
              mfun(km)=mnew
              PredKm(km)=Pred
              mm = min(mm+1,Mmax)

              call Jacob(paras,dgamma,pold,pcold,cd,x,nw,xs,xcd,nsdt,Jg)
              norm_g = norm2_4(g)

            else
              del = 0.5_dp*del
            end if

          end do

          if (norm_g > 1.0e-6_dp) then
            info = 1
          end if
        end subroutine

      end module umat_model


      subroutine umat(stress,statev,ddsdde,sse,spd,scd, 
     & rpl,ddsddt,drplde,drpldt, 
     &    stran,dstran,time,dtime,temp,dtemp,predef,dpred,cmname,
     &    ndi,nshr,ntens,nstatv,props,nprops,coords,drot,pnewdt,
     &    celent,dfgrd0,dfgrd1,noel,npt,layer,kspt,jstep,kinc)

        use umat_kinds
        use umat_utils
        use umat_model
        implicit none

        character(len=80), intent(in) :: cmname

        integer, intent(in) :: ndi,nshr,ntens,nstatv,nprops
        integer, intent(in) :: noel,npt,layer,kspt,kinc
        integer, intent(in) :: jstep(4)

        real(dp), intent(inout) :: stress(ntens),statev(nstatv),
     # ddsdde(ntens,ntens)
        real(dp), intent(inout) :: sse,spd,scd,rpl,ddsddt(ntens),
     # drplde(ntens),drpldt
        real(dp), intent(in) :: stran(ntens),dstran(ntens),time(2),dtime
     #   ,temp,dtemp
        real(dp), intent(in) :: predef(1),dpred(1),props(nprops),
     $  coords(3),drot(3,3)
        real(dp), intent(in) :: dfgrd0(3,3),dfgrd1(3,3),celent
        real(dp), intent(inout) :: pnewdt

        real(dp) :: lambda,kappa,Mf,nu,e0,cp,ck,r
        real(dp) :: Beta,Ftol,tol
        real(dp) :: s(6),dstra(6),dstra1(6),De(6,6)
        real(dp) :: II(6,6),IP(6,6),Ivol(6,6),Isym(6,6)
        real(dp) :: st(6),x(4),xold(4),paras(4),sdold(6),delta(6),
     #  dgamma(6)
        real(dp) :: g(4),nw(6),xs(4),xcd(2),DDSDDE1(6,6)
        real(dp) :: pold,qold,pcold,p,q,pc,dphi,pt,qt,dev,cd,norm_g
        real(dp) :: BKw,GKw,f,nsdt
        integer :: i,j,iteration,info_trust,info_tan

        Beta = 0.5e-12_dp
        Ftol = sqrt(2.0_dp*Beta)
        tol  = 1.0e-12_dp

        lambda = props(1)
        kappa  = props(2)
        Mf     = props(3)
        nu     = props(4)
        e0     = props(5)

        cp = (1.0_dp+e0)/(lambda-kappa)
        ck = (1.0_dp+e0)/kappa
        r  = 3.0_dp*(1.0_dp-2.0_dp*nu)/(2.0_dp*(1.0_dp+nu))

        paras(1)=Mf
        paras(2)=cp
        paras(3)=ck
        paras(4)=r

        call TenMat1(II,IP,Ivol,Isym)

        call set_zero_vec6(delta)
        do i=1,3
          delta(i)=1.0_dp
        end do

        call set_zero_vec6(s)
        call set_zero_vec6(dstra)
        call set_zero_vec6(dstra1)

        if (ntens == 6) then
          do i=1,3
            s(i)   = -stress(i)
            s(i+3) = -stress(i+3)
            dstra(i)   = -dstran(i)
            dstra(i+3) = -dstran(i+3)/2.0_dp
            dstra1(i)   = -dstran(i)
            dstra1(i+3) = -dstran(i+3)
          end do
        else
          do i=1,3
            s(i) = -stress(i)
            dstra(i) = -dstran(i)
            dstra1(i)= -dstran(i)
          end do
          s(4) = -stress(4)
          dstra(4) = -dstran(4)/2.0_dp
          dstra1(4)= -dstran(4)
        end if

        dev = dstra(1)+dstra(2)+dstra(3)
        do i=1,6
          dgamma(i)=dstra(i)-delta(i)*dev/3.0_dp
        end do

        call pqs(s,pold,qold)

        do i=1,3
          sdold(i)=s(i)-pold
          sdold(i+3)=s(i+3)
        end do

        if (time(2) < 1.0e-10_dp) then
          pcold = (Mf*Mf*pold*pold+qold*qold)/(Mf*Mf*pold)
        else
          pcold = statev(1)
        end if

        dphi = 0.0_dp
        x(1)=pold
        x(2)=qold
        x(3)=pcold
        x(4)=dphi
        xold = x

        BKw = secant_bulk(pold, ck, dev)
        GKw = r*BKw

        do i=1,6
          st(i)=0.0_dp
          do j=1,6
          De(i,j)=(3.0_dp*BKw-2.0_dp*GKw)*Ivol(i,j)+2.0_dp*GKw*Isym(i,j)
            st(i)=st(i)+De(i,j)*dstra1(j)
          end do
          st(i)=st(i)+s(i)
        end do

        cd = norm2_6_eng(st)
        if (cd < 1.0_dp) cd = 1.0_dp

        pt = (st(1)+st(2)+st(3))/3.0_dp
        qt = sqrt(((st(1)-st(2))**2+(st(2)-st(3))**2 + (st(3)-st(1))**2 
     &      + 6.0_dp*(st(4)**2+st(5)**2+st(6)**2))/2.0_dp)

        x(1)=pt
        x(2)=qt
        x(3)=pcold
        x(4)=0.0_dp

        call TrustSolve(paras,sdold,dev,dgamma,xold,cd,x,
     #   iteration,info_trust)

        if (info_trust /= 0) then
          pnewdt = 0.25_dp
          call eye66(II)
          do i=1,6
            do j=1,6
              DDSDDE1(i,j) = -1.0e60_dp*II(i,j)
            end do
          end do
          do i=1,6
            s(i) = -1.0e10_dp
          end do
          pc = -1.0e10_dp
        else
          call eval_state(paras,sdold,dev,dgamma,pold,pcold,cd,
     $   x,g,nw,xs,xcd,nsdt)
          norm_g = norm2_4(g)

          p = x(1)
          q = x(2)
          pc = x(3)
          dphi = x(4)

          do i=1,6
            s(i)=p*delta(i)+sqrt(2.0_dp/3.0_dp)*q*nw(i)
          end do

          call ConsStiff(nw,IP,Ivol,DDSDDE1,paras,dgamma,pold,
     #    xs,xcd,x,info_tan)

          if (info_tan /= 0) then
            pnewdt = 0.25_dp
            call eye66(II)
            do i=1,6
              do j=1,6
                DDSDDE1(i,j) = -1.0e60_dp*II(i,j)
              end do
            end do
            do i=1,6
              s(i) = -1.0e10_dp
            end do
            pc = -1.0e10_dp
          end if
        end if

        if (ntens == 6) then
          do i=1,6
            stress(i) = -s(i)
          end do
          do i=1,6
            do j=1,6
              ddsdde(i,j)=DDSDDE1(i,j)
            end do
          end do
        else
          do i=1,3
            stress(i) = -s(i)
          end do
          stress(4) = -s(4)
          do i=1,ntens
            do j=1,ntens
              ddsdde(i,j)=0.0_dp
            end do
          end do
          do i=1,4
            do j=1,4
              ddsdde(i,j)=DDSDDE1(i,j)
            end do
          end do
        end if

        f = x(2)*x(2)/(Mf*Mf) + x(1)*(x(1)-pc)
        statev(1)=pc
        statev(2)=real(iteration,dp)
        statev(3)=norm2_4(g)
        statev(4)=f
        statev(5)=statev(5)+1.0_dp

      end subroutine umat